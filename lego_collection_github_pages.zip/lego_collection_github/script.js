/*
  MY LEGO COLLECTION — EDIT YOUR INVENTORY HERE
  Add or remove objects in the sets array. For each set:
  name, number, theme, condition, description, price, photo, status
  photo can be a relative image path (example: "images/my-set.jpg")
  or a direct image URL. For Google Photos, use a publicly shareable
  image URL that actually displays the image; regular album share links
  may open a Google Photos page instead of an embeddable image.
  Change CONTACT_EMAIL to your preferred contact email.
*/
const CONTACT_EMAIL = "your-email@example.com";

const sets = [
  {
    name: "Millennium Falcon", number: "75257", theme: "Star Wars",
    condition: "Used — Good",
    description: "Example listing. Describe which pieces, minifigures, and instructions are included.",
    price: 180, photo: "", status: "Available"
  },
  {
    name: "Police Station", number: "60141", theme: "City",
    condition: "Used — Very Good",
    description: "Example listing. Add your own details about completeness, wear, and original box.",
    price: 120, photo: "", status: "Available"
  },
  {
    name: "Bulldozer", number: "42131", theme: "Technic",
    condition: "Used — Good",
    description: "Example listing. Mention whether functions work and which accessories are included.",
    price: 150, photo: "", status: "Available"
  },
  {
    name: "Hogwarts Castle", number: "71043", theme: "Harry Potter",
    condition: "Used — Very Good",
    description: "Example listing. Describe the condition and any missing pieces.",
    price: 250, photo: "", status: "Available"
  },
  {
    name: "Avengers Tower", number: "76269", theme: "Marvel",
    condition: "Used — Good",
    description: "Example listing. Add minifigure, instruction, and box details.",
    price: 200, photo: "", status: "Available"
  },
  {
    name: "Fire Dragon", number: "71753", theme: "Ninjago",
    condition: "Used — Very Good",
    description: "Example listing. Add a description of the set and its condition.",
    price: 90, photo: "", status: "Available"
  }
];

const themeInfo = [
  {name:"All Sets", emoji:"🧱"},
  {name:"Star Wars", emoji:"🚀"},
  {name:"City", emoji:"🏙️"},
  {name:"Technic", emoji:"⚙️"},
  {name:"Creator", emoji:"🎨"},
  {name:"Harry Potter", emoji:"🪄"},
  {name:"Marvel", emoji:"🦸"},
  {name:"DC", emoji:"🦇"},
  {name:"Ninjago", emoji:"🐉"},
  {name:"Other", emoji:"✨"}
];

let activeTheme = "All Sets";
let selectedSet = null;

const nav = document.getElementById("theme-nav");
const grid = document.getElementById("set-grid");
const search = document.getElementById("search");
const dialog = document.getElementById("contact-dialog");

function renderThemeNav() {
  nav.innerHTML = themeInfo.map(theme => `
    <button class="theme-tab ${theme.name === activeTheme ? "active" : ""}" data-theme="${theme.name}">
      <span class="tab-emoji">${theme.emoji}</span>${theme.name}
    </button>`).join("");
  nav.querySelectorAll("button").forEach(button => {
    button.addEventListener("click", () => {
      activeTheme = button.dataset.theme;
      renderThemeNav();
      renderSets();
    });
  });
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[ch]));
}

function money(value) {
  return new Intl.NumberFormat("en-US", {style:"currency", currency:"USD", maximumFractionDigits:0}).format(value);
}

function cardHTML(set, index) {
  const sold = String(set.status).toLowerCase() === "sold";
  const photo = set.photo ? `
    <img src="${escapeHTML(set.photo)}" alt="${escapeHTML(set.name)} LEGO set photo"
      onerror="this.style.display='none';this.nextElementSibling.hidden=false">
    <div class="photo-placeholder" hidden><span>🧱</span><small>Add a set photo in script.js</small></div>
  ` : `<div class="photo-placeholder"><span>🧱</span><small>Add a set photo in script.js</small></div>`;
  return `<article class="set-card">
    <div class="set-photo">${photo}<span class="theme-badge">${escapeHTML(set.theme)}</span>${sold ? '<span class="sold-ribbon">SOLD</span>' : ''}</div>
    <div class="set-content">
      <h3>${escapeHTML(set.name)} <span class="set-number">(${escapeHTML(set.number)})</span></h3>
      <p class="condition">Condition: <strong>${escapeHTML(set.condition)}</strong></p>
      <p class="description">${escapeHTML(set.description)}</p>
      <div class="price-row"><span class="price">${money(set.price)}</span><span class="availability ${sold ? "sold" : ""}">${sold ? "Sold" : "Available"}</span></div>
      <button class="button card-contact" data-index="${index}" ${sold ? "disabled" : ""}>${sold ? "This set is sold" : "✉ Contact me"}</button>
    </div>
  </article>`;
}

function renderSets() {
  const term = search.value.trim().toLowerCase();
  const filtered = sets.map((set, index) => ({set,index})).filter(({set}) => {
    const themeMatches = activeTheme === "All Sets" || set.theme === activeTheme;
    const searchable = [set.name,set.number,set.theme,set.condition,set.description].join(" ").toLowerCase();
    return themeMatches && searchable.includes(term);
  });
  document.getElementById("collection-title").textContent = activeTheme;
  document.getElementById("set-count").textContent = `${filtered.length} ${filtered.length === 1 ? "set" : "sets"}`;
  grid.innerHTML = filtered.map(({set,index}) => cardHTML(set,index)).join("");
  document.getElementById("empty-state").hidden = filtered.length !== 0;
  grid.querySelectorAll("[data-index]").forEach(button => {
    button.addEventListener("click", () => openContact(sets[Number(button.dataset.index)]));
  });
}

function openContact(set) {
  selectedSet = set;
  document.getElementById("dialog-title").textContent = `Ask about ${set.name}`;
  document.getElementById("dialog-details").textContent = `Set ${set.number} · ${set.theme} · ${money(set.price)} · ${set.condition}`;
  document.querySelector('[name="message"]').value = `Hello, I'm interested in ${set.name} (set ${set.number}), listed for ${money(set.price)}. Is it still available?`;
  dialog.showModal();
}

search.addEventListener("input", renderSets);
document.getElementById("close-dialog").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});
document.getElementById("contact-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const subject = `LEGO set inquiry: ${selectedSet.name} (${selectedSet.number})`;
  const body = `Name: ${form.get("name")}\nReply email: ${form.get("email")}\n\n${form.get("message")}`;
  window.location.href = `mailto:${encodeURIComponent(CONTACT_EMAIL)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  dialog.close();
});

renderThemeNav();
renderSets();
