# My LEGO Collection — GitHub Pages website

A colorful, mobile-friendly, no-checkout storefront for selling a personal LEGO collection. It is a static website built with plain HTML, CSS, and JavaScript, so it can be hosted free with GitHub Pages.

## Publish it with GitHub Pages

1. Sign in to GitHub and create a **new public repository** (for example, `lego-collection`).
2. Upload `index.html`, `styles.css`, `script.js`, and this `README.md` to the repository root. You can upload the whole folder's files through **Add file → Upload files**.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then click **Save**.
6. Wait a minute or two. GitHub will show your website URL in the Pages section.

## Add your real inventory

Open `script.js` and find the `sets` array near the top. Replace the example listings with your own details. Each set uses these fields:

- `name`: set name
- `number`: LEGO set number
- `theme`: use one of the theme names in `themeInfo` (for example, `Star Wars`, `City`, `Technic`, `Creator`, `Harry Potter`, `Marvel`, `DC`, `Ninjago`, or `Other`)
- `condition`: condition as you want it displayed
- `description`: completeness, included minifigures, instructions, box, wear, and other details
- `price`: numeric price in US dollars (example: `125`)
- `photo`: path to an image in your repository (recommended), or an image URL
- `status`: `Available` or `Sold`

Example:

```js
{
  name: "My LEGO Set",
  number: "12345",
  theme: "City",
  condition: "Used — Very Good",
  description: "Complete set with instructions. No original box.",
  price: 75,
  photo: "images/my-set.jpg",
  status: "Available"
}
```

### Add photos

For the most reliable setup, create an `images` folder in your repository and upload your photos there. Set `photo` to the relative path, such as `images/my-set.jpg`. Use simple filenames without spaces when possible.

Google Photos album-sharing URLs often open the Google Photos website rather than directly displaying the image inside your product card. This starter website does not include Google sign-in or the Google Photos API. If you want to use Google Photos, use an image URL that is publicly embeddable, or download your own photos from Google Photos and upload them to the `images` folder. A full Google Photos picker integration requires Google Cloud project setup, OAuth credentials, and additional code.

## Set your contact email

In `script.js`, change:

```js
const CONTACT_EMAIL = "your-email@example.com";
```

to the email address where you want buyer inquiries to go. The Contact button opens the visitor's email app with a draft containing the set name, price, and their message. This static site does not store inquiries or send mail by itself.

## Notes

- All sample sets and prices are placeholders; replace them before publishing.
- This site does not take payments or reserve inventory automatically.
- This is an independent fan/collector website and is not affiliated with or endorsed by the LEGO Group.
